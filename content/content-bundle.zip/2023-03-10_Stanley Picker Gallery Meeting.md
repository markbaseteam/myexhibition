---
quickshare-date: 2023-03-10 12:22:30
quickshare-url: "https://noteshare.space/note/clf2icyfk244701pjkhy1mhzx#1teJ0MzxCUSe/O3uwv/IGZbq4XJmON9PuG6LBayCpYQ"
id: 202303171153
title: 2023-03-10_Stanley Picker Gallery Meeting
reviewed date: 2023-03-10 11:53
date: 2023-03-10
place: 
- online
- Stanley Picker
type: meeting
tags:
- exhibition
- meeting
---

## Proposal
![[Dailiness and Atmosphere (Proposal).docx - Google Docs.pdf]]

## Note

질문:
- **프로젝터** 종류 (미리 workshop에서 테스트 해 볼 예정) (거리 distance? ) how many projector I can use?
- size of the ==**monitor**== I can put on the wall?
	- 28 inch LG monitor (https://www.lg.com/us/monitors/lg-28mq780-b)
- Changing the **display plan**
	- cancel no. 3's 4 videos but only no.1 and no.2
- **washhand stand** can be covered by black fabric?
- 언제쯤부터 설치 테스트 해볼 수 있을까?
- 외부 벽에 포스터 같은거 설명문 붙여도 되나 (문 바로 옆)

계획:
- 5월부터 펀딩 받기 시작
- 약 3개월 간 펀딩 모집
- 8월부터 전시 및 배송 집중 준비
- 9월 초중순 쯤에 후원자 분들에게 기프트 발송 시작